# PasarKita – Marketplace Tradisional

Aplikasi contoh marketplace sederhana menggunakan PHP Native, MySQLi, dan Bootstrap 5.

## Fitur
- Daftar dan pencarian produk
- Detail produk
- Keranjang belanja berbasis session
- Checkout dan penyimpanan pesanan serta detail pesanan
- Pengurangan stok secara transaksional
- CRUD produk (halaman admin sederhana)

## Instalasi lokal
1. Jalankan Apache dan MySQL dari XAMPP.
2. Buat database dengan mengimpor `database.sql` melalui phpMyAdmin.
3. Salin `config/database.example.php` menjadi `config/database.php` (atau buat file tersebut dari contoh) lalu sesuaikan host, username, password, dan nama database.
4. Letakkan folder proyek di `htdocs/pasarkita_marketplace`.
5. Buka `http://localhost/pasarkita_marketplace/`.

## Catatan penting
- Contoh ini adalah starter project tugas kuliah, belum memiliki autentikasi dan otorisasi admin. Batasi halaman `admin/` sebelum dipakai publik.
- Keranjang pada versi starter disimpan di session. Tabel `keranjang` disediakan dalam skema database sebagai rancangan relasional.
- `id_user=1` dipakai sebagai pengguna demo untuk pencatatan pesanan dan produk.
- Untuk hosting, sesuaikan kredensial database di `config/database.php`. Jangan commit file tersebut ke GitHub.
- Gunakan HTTPS dan validasi/otorisasi yang lebih lengkap sebelum penggunaan produksi.
