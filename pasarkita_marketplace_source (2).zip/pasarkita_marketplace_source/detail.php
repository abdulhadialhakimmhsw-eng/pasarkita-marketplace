<?php
require "config/database.php";
$id=(int)($_GET['id']??0);
$stmt=$conn->prepare("SELECT p.*,k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.id_kategori=k.id_kategori WHERE p.id_produk=?");
$stmt->bind_param("i",$id);$stmt->execute();$p=$stmt->get_result()->fetch_assoc();
if(!$p){http_response_code(404);die("Produk tidak ditemukan. <a href='index.php'>Kembali</a>");}
$pageTitle=$p['nama_produk']; include "includes/header.php";
?>
<div class="row g-4"><div class="col-md-6"><img class="img-fluid rounded shadow-sm w-100" src="<?= htmlspecialchars($p['gambar'] ?: 'https://placehold.co/800x600?text=PasarKita') ?>" alt=""></div>
<div class="col-md-6"><small class="text-muted"><?= htmlspecialchars($p['nama_kategori']??'Umum') ?></small>
<h2 class="fw-bold"><?= htmlspecialchars($p['nama_produk']) ?></h2><h4 class="price">Rp <?= number_format($p['harga'],0,',','.') ?></h4>
<p><?= nl2br(htmlspecialchars($p['deskripsi']??'')) ?></p><p>Stok tersedia: <b><?= (int)$p['stok'] ?></b></p>
<?php if($p['stok']>0): ?><form action="add_to_cart.php" method="post" class="d-flex gap-2">
<input type="hidden" name="id_produk" value="<?= (int)$p['id_produk'] ?>"><input class="form-control" style="max-width:100px" type="number" name="jumlah" min="1" max="<?= (int)$p['stok'] ?>" value="1" required>
<button class="btn btn-success">Tambah ke Keranjang</button></form><?php else: ?><button class="btn btn-secondary" disabled>Stok Habis</button><?php endif; ?>
<a href="index.php" class="btn btn-link mt-3">Kembali ke produk</a></div></div>
<?php include "includes/footer.php"; ?>
