<?php
session_start();$id=(int)($_SESSION['success_order']??0);unset($_SESSION['success_order']);if(!$id){header("Location: index.php");exit;}
$pageTitle="Pesanan Berhasil";include "includes/header.php";?>
<div class="text-center py-5"><h2 class="text-success">Pesanan Berhasil Dibuat!</h2><p>Nomor pesanan Anda: <b>#<?= $id ?></b></p><p>Data pesanan telah disimpan ke database.</p><a class="btn btn-success" href="index.php">Kembali Belanja</a></div>
<?php include "includes/footer.php"; ?>
