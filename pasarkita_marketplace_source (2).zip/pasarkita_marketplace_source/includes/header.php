<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
$pageTitle = $pageTitle ?? "PasarKita";
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($pageTitle) ?> - PasarKita</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#f6f8f6}.navbar{background:#176b45}.navbar-brand,.nav-link{color:#fff!important}
.product-img{height:190px;object-fit:cover}.price{color:#176b45;font-weight:700}
footer{margin-top:50px;padding:24px;background:#e9f1ec}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
<div class="container"><a class="navbar-brand fw-bold" href="index.php">PasarKita</a>
<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="nav"><ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Produk</a></li>
<li class="nav-item"><a class="nav-link" href="cart.php">Keranjang (<?= array_sum($_SESSION['cart']) ?>)</a></li>
<li class="nav-item"><a class="nav-link" href="admin/products.php">Kelola Produk</a></li>
</ul></div></div></nav>
<main class="container py-4">
