<?php
session_start();require "config/database.php";
if(empty($_SESSION['cart'])){header("Location: cart.php");exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $nama=trim($_POST['nama']??'');$email=trim($_POST['email']??'');$alamat=trim($_POST['alamat']??'');
 if($nama===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||$alamat==='')$error="Lengkapi nama, email yang valid, dan alamat.";
 else{
  $conn->begin_transaction();
  try{
   $total=0;$rows=[];
   foreach($_SESSION['cart'] as $id=>$qty){
    $id=(int)$id;$qty=(int)$qty;
    $s=$conn->prepare("SELECT nama_produk,harga,stok FROM produk WHERE id_produk=? FOR UPDATE");$s->bind_param("i",$id);$s->execute();$p=$s->get_result()->fetch_assoc();
    if(!$p||$qty<1||$qty>$p['stok'])throw new Exception("Stok produk berubah atau tidak mencukupi.");
    $subtotal=$p['harga']*$qty;$total+=$subtotal;$rows[]=[$id,$qty,$p['harga'],$subtotal];
   }
   $uid=2;
   $s=$conn->prepare("INSERT INTO pesanan(id_user,nama_pembeli,email_pembeli,alamat_pengiriman,tanggal_pesanan,total_harga,status) VALUES(?,?,?,?,NOW(),?,'Menunggu')");
   $s->bind_param("isssd",$uid,$nama,$email,$alamat,$total);$s->execute();$orderId=$conn->insert_id;
   foreach($rows as $r){
    [$pid,$qty,$price,$sub]=$r;
    $d=$conn->prepare("INSERT INTO detail_pesanan(id_pesanan,id_produk,jumlah,harga,subtotal) VALUES(?,?,?,?,?)");$d->bind_param("iiidd",$orderId,$pid,$qty,$price,$sub);$d->execute();
    $u=$conn->prepare("UPDATE produk SET stok=stok-? WHERE id_produk=?");$u->bind_param("ii",$qty,$pid);$u->execute();
   }
   $conn->commit();$_SESSION['cart']=[];
   $_SESSION['success_order']=$orderId;header("Location: success.php");exit;
  }catch(Throwable $e){$conn->rollback();$error=$e->getMessage();}
 }
}
$pageTitle="Checkout";include "includes/header.php";
?>
<h2 class="fw-bold mb-4">Checkout</h2><?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post" class="card card-body shadow-sm" style="max-width:650px">
<div class="mb-3"><label class="form-label">Nama Pembeli</label><input class="form-control" name="nama" required></div>
<div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email" required></div>
<div class="mb-3"><label class="form-label">Alamat Pengiriman</label><textarea class="form-control" name="alamat" rows="3" required></textarea></div>
<button class="btn btn-success">Konfirmasi Pesanan</button></form>
<?php include "includes/footer.php"; ?>
