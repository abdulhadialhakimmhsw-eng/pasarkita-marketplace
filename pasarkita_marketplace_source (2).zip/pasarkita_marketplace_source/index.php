<?php
require "config/database.php";
$pageTitle = "Daftar Produk";
$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $stmt = $conn->prepare("SELECT p.*, k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.id_kategori=k.id_kategori WHERE p.nama_produk LIKE ? ORDER BY p.id_produk DESC");
    $like = "%$q%"; $stmt->bind_param("s", $like); $stmt->execute(); $products = $stmt->get_result();
} else {
    $products = $conn->query("SELECT p.*, k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.id_kategori=k.id_kategori ORDER BY p.id_produk DESC");
}
include "includes/header.php";
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
<div><h2 class="fw-bold">Produk Pilihan</h2><p class="text-muted mb-0">Temukan kebutuhan sehari-hari dari penjual lokal.</p></div>
<form class="d-flex" method="get"><input class="form-control me-2" name="q" placeholder="Cari produk..." value="<?= htmlspecialchars($q) ?>"><button class="btn btn-success">Cari</button></form>
</div>
<div class="row g-4">
<?php if ($products && $products->num_rows): while($p=$products->fetch_assoc()): ?>
<div class="col-12 col-sm-6 col-lg-3"><div class="card h-100 shadow-sm border-0">
<img class="card-img-top product-img" src="<?= htmlspecialchars($p['gambar'] ?: 'https://placehold.co/600x400?text=PasarKita') ?>" alt="<?= htmlspecialchars($p['nama_produk']) ?>">
<div class="card-body d-flex flex-column"><small class="text-muted"><?= htmlspecialchars($p['nama_kategori'] ?? 'Umum') ?></small>
<h5 class="card-title mt-1"><?= htmlspecialchars($p['nama_produk']) ?></h5>
<div class="price mb-2">Rp <?= number_format($p['harga'],0,',','.') ?></div>
<p class="small text-muted">Stok: <?= (int)$p['stok'] ?></p>
<a class="btn btn-outline-success mt-auto" href="detail.php?id=<?= (int)$p['id_produk'] ?>">Lihat Detail</a></div></div></div>
<?php endwhile; else: ?><div class="col-12"><div class="alert alert-info">Produk belum tersedia atau tidak ditemukan.</div></div><?php endif; ?>
</div>
<?php include "includes/footer.php"; ?>
