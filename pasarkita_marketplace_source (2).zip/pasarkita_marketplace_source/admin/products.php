<?php
require "../config/database.php";$pageTitle="Kelola Produk";include "../includes/header.php";
if(isset($_GET['delete'])){$id=(int)$_GET['delete'];$s=$conn->prepare("DELETE FROM produk WHERE id_produk=?");$s->bind_param("i",$id);$s->execute();header("Location: products.php");exit;}
$rows=$conn->query("SELECT p.*,k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.id_kategori=k.id_kategori ORDER BY p.id_produk DESC");
?>
<div class="d-flex justify-content-between align-items-center mb-3"><h2>Kelola Produk</h2><a class="btn btn-success" href="product_form.php">Tambah Produk</a></div>
<div class="table-responsive"><table class="table table-bordered bg-white"><thead><tr><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr></thead><tbody>
<?php while($p=$rows->fetch_assoc()): ?><tr><td><?= htmlspecialchars($p['nama_produk']) ?></td><td><?= htmlspecialchars($p['nama_kategori']??'-') ?></td><td>Rp <?= number_format($p['harga'],0,',','.') ?></td><td><?= (int)$p['stok'] ?></td><td><a class="btn btn-sm btn-primary" href="product_form.php?id=<?= (int)$p['id_produk'] ?>">Edit</a> <a class="btn btn-sm btn-danger" onclick="return confirm('Hapus produk ini?')" href="?delete=<?= (int)$p['id_produk'] ?>">Hapus</a></td></tr><?php endwhile; ?>
</tbody></table></div><?php include "../includes/footer.php"; ?>
