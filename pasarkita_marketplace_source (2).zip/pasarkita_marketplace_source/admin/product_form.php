<?php
require "../config/database.php";$id=(int)($_GET['id']??0);$p=['nama_produk'=>'','id_kategori'=>'','deskripsi'=>'','harga'=>'','stok'=>'','gambar'=>''];$title="Tambah Produk";
if($id){$s=$conn->prepare("SELECT * FROM produk WHERE id_produk=?");$s->bind_param("i",$id);$s->execute();$found=$s->get_result()->fetch_assoc();if($found){$p=$found;$title="Edit Produk";}}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $nama=trim($_POST['nama_produk']??'');$kat=(int)($_POST['id_kategori']??0);$desk=trim($_POST['deskripsi']??'');$harga=(float)($_POST['harga']??0);$stok=(int)($_POST['stok']??0);$gambar=trim($_POST['gambar']??'');
 if($nama===''||$kat<1||$harga<0||$stok<0)$error="Periksa kembali data produk.";
 else if($id){$s=$conn->prepare("UPDATE produk SET id_kategori=?,nama_produk=?,deskripsi=?,harga=?,stok=?,gambar=? WHERE id_produk=?");$s->bind_param("issdisi",$kat,$nama,$desk,$harga,$stok,$gambar,$id);$s->execute();header("Location: products.php");exit;}
 else{$uid=1;$s=$conn->prepare("INSERT INTO produk(id_user,id_kategori,nama_produk,deskripsi,harga,stok,gambar) VALUES(?,?,?,?,?,?,?)");$s->bind_param("iissdis",$uid,$kat,$nama,$desk,$harga,$stok,$gambar);$s->execute();header("Location: products.php");exit;}
}
$cats=$conn->query("SELECT * FROM kategori ORDER BY nama_kategori");$pageTitle=$title;include "../includes/header.php";
?>
<h2><?= htmlspecialchars($title) ?></h2><?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post" class="card card-body shadow-sm" style="max-width:700px">
<label class="form-label">Nama Produk</label><input class="form-control mb-3" name="nama_produk" required value="<?= htmlspecialchars($p['nama_produk']) ?>">
<label class="form-label">Kategori</label><select class="form-select mb-3" name="id_kategori" required><option value="">Pilih kategori</option><?php while($c=$cats->fetch_assoc()): ?><option value="<?= $c['id_kategori'] ?>" <?= $p['id_kategori']==$c['id_kategori']?'selected':'' ?>><?= htmlspecialchars($c['nama_kategori']) ?></option><?php endwhile; ?></select>
<label class="form-label">Deskripsi</label><textarea class="form-control mb-3" name="deskripsi"><?= htmlspecialchars($p['deskripsi']) ?></textarea>
<label class="form-label">Harga</label><input class="form-control mb-3" type="number" min="0" step="0.01" name="harga" required value="<?= htmlspecialchars($p['harga']) ?>">
<label class="form-label">Stok</label><input class="form-control mb-3" type="number" min="0" name="stok" required value="<?= htmlspecialchars($p['stok']) ?>">
<label class="form-label">URL gambar (opsional)</label><input class="form-control mb-3" name="gambar" value="<?= htmlspecialchars($p['gambar']) ?>">
<button class="btn btn-success">Simpan</button></form><?php include "../includes/footer.php"; ?>
