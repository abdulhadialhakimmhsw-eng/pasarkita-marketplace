<?php
session_start(); require "config/database.php";
$id=(int)($_POST['id_produk']??0);$qty=max(1,(int)($_POST['jumlah']??1));
$stmt=$conn->prepare("SELECT stok FROM produk WHERE id_produk=?");$stmt->bind_param("i",$id);$stmt->execute();$p=$stmt->get_result()->fetch_assoc();
if(!$p){header("Location: index.php");exit;}
$current=(int)($_SESSION['cart'][$id]??0);
if($current+$qty>(int)$p['stok']) $_SESSION['flash']="Jumlah melebihi stok yang tersedia.";
else {$_SESSION['cart'][$id]=$current+$qty;$_SESSION['flash']="Produk berhasil ditambahkan ke keranjang.";}
header("Location: cart.php");exit;
