CREATE TABLE users (
 id_user INT AUTO_INCREMENT PRIMARY KEY,
 nama VARCHAR(100) NOT NULL,
 email VARCHAR(100) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('Penjual','Pembeli') NOT NULL DEFAULT 'Pembeli'
) ENGINE=InnoDB;

CREATE TABLE kategori (
 id_kategori INT AUTO_INCREMENT PRIMARY KEY,
 nama_kategori VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE produk (
 id_produk INT AUTO_INCREMENT PRIMARY KEY,
 id_user INT NOT NULL,
 id_kategori INT NOT NULL,
 nama_produk VARCHAR(150) NOT NULL,
 deskripsi TEXT,
 harga DECIMAL(12,2) NOT NULL DEFAULT 0,
 stok INT NOT NULL DEFAULT 0,
 gambar VARCHAR(255),
 CONSTRAINT fk_produk_user FOREIGN KEY(id_user) REFERENCES users(id_user),
 CONSTRAINT fk_produk_kategori FOREIGN KEY(id_kategori) REFERENCES kategori(id_kategori)
) ENGINE=InnoDB;

CREATE TABLE keranjang (
 id_keranjang INT AUTO_INCREMENT PRIMARY KEY,
 id_user INT NOT NULL,
 id_produk INT NOT NULL,
 jumlah INT NOT NULL DEFAULT 1,
 UNIQUE KEY uq_user_produk(id_user,id_produk),
 CONSTRAINT fk_keranjang_user FOREIGN KEY(id_user) REFERENCES users(id_user),
 CONSTRAINT fk_keranjang_produk FOREIGN KEY(id_produk) REFERENCES produk(id_produk)
) ENGINE=InnoDB;

CREATE TABLE pesanan (
 id_pesanan INT AUTO_INCREMENT PRIMARY KEY,
 id_user INT NOT NULL,
 nama_pembeli VARCHAR(100) NOT NULL,
 email_pembeli VARCHAR(100) NOT NULL,
 alamat_pengiriman TEXT NOT NULL,
 tanggal_pesanan DATETIME NOT NULL,
 total_harga DECIMAL(12,2) NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'Menunggu',
 CONSTRAINT fk_pesanan_user FOREIGN KEY(id_user) REFERENCES users(id_user)
) ENGINE=InnoDB;

CREATE TABLE detail_pesanan (
 id_detail INT AUTO_INCREMENT PRIMARY KEY,
 id_pesanan INT NOT NULL,
 id_produk INT NOT NULL,
 jumlah INT NOT NULL,
 harga DECIMAL(12,2) NOT NULL,
 subtotal DECIMAL(12,2) NOT NULL,
 CONSTRAINT fk_detail_pesanan FOREIGN KEY(id_pesanan) REFERENCES pesanan(id_pesanan),
 CONSTRAINT fk_detail_produk FOREIGN KEY(id_produk) REFERENCES produk(id_produk)
) ENGINE=InnoDB;

INSERT INTO users(nama,email,password,role) VALUES
('Admin Demo','admin@example.com','$2y$10$placeholderhash','Penjual'),
('Pembeli Demo','pembeli@example.com','$2y$10$placeholderhash','Pembeli');

INSERT INTO kategori(nama_kategori) VALUES
('Makanan'),('Minuman'),('Kerajinan'),('Kebutuhan Rumah');

INSERT INTO produk(id_user,id_kategori,nama_produk,deskripsi,harga,stok,gambar) VALUES
(1,1,'Keripik Singkong','Keripik singkong renyah produksi lokal.',12000,30,'https://placehold.co/600x400?text=Keripik+Singkong'),
(1,2,'Kopi Bubuk Tradisional','Kopi bubuk pilihan dari petani lokal.',25000,20,'https://placehold.co/600x400?text=Kopi+Bubuk'),
(1,3,'Anyaman Bambu','Kerajinan anyaman bambu buatan pengrajin lokal.',35000,12,'https://placehold.co/600x400?text=Anyaman+Bambu');
