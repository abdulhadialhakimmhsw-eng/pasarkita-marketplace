<?php
session_start();
require "config/database.php";
if(isset($_GET['remove'])){unset($_SESSION['cart'][(int)$_GET['remove']]);header("Location: cart.php");exit;}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['qty'])){
 foreach($_POST['qty'] as $id=>$qty){$id=(int)$id;$qty=max(1,(int)$qty);$s=$conn->prepare("SELECT stok FROM produk WHERE id_produk=?");$s->bind_param("i",$id);$s->execute();$p=$s->get_result()->fetch_assoc();if($p)$_SESSION['cart'][$id]=min($qty,(int)$p['stok']);}
 header("Location: cart.php");exit;
}
$pageTitle="Keranjang";include "includes/header.php";
if(!empty($_SESSION['flash'])){echo '<div class="alert alert-info">'.htmlspecialchars($_SESSION['flash']).'</div>';unset($_SESSION['flash']);}
$total=0;$items=[];
foreach($_SESSION['cart'] as $id=>$qty){$s=$conn->prepare("SELECT * FROM produk WHERE id_produk=?");$s->bind_param("i",$id);$s->execute();$p=$s->get_result()->fetch_assoc();if($p){$p['jumlah']=$qty;$p['subtotal']=$p['harga']*$qty;$total+=$p['subtotal'];$items[]=$p;}else unset($_SESSION['cart'][$id]);}
?>
<h2 class="fw-bold mb-4">Keranjang Belanja</h2>
<?php if(!$items): ?><div class="alert alert-info">Keranjang masih kosong. <a href="index.php">Mulai belanja</a>.</div>
<?php else: ?><form method="post"><div class="table-responsive"><table class="table align-middle bg-white"><thead><tr><th>Produk</th><th>Harga</th><th style="width:130px">Jumlah</th><th>Subtotal</th><th></th></tr></thead><tbody>
<?php foreach($items as $it): ?><tr><td><?= htmlspecialchars($it['nama_produk']) ?></td><td>Rp <?= number_format($it['harga'],0,',','.') ?></td>
<td><input class="form-control" type="number" min="1" max="<?= (int)$it['stok'] ?>" name="qty[<?= (int)$it['id_produk'] ?>]" value="<?= (int)$it['jumlah'] ?>"></td>
<td>Rp <?= number_format($it['subtotal'],0,',','.') ?></td><td><a class="btn btn-sm btn-outline-danger" href="cart.php?remove=<?= (int)$it['id_produk'] ?>">Hapus</a></td></tr><?php endforeach; ?>
</tbody></table></div><button class="btn btn-outline-success">Perbarui Keranjang</button></form>
<div class="text-end mt-4"><h4>Total: <span class="price">Rp <?= number_format($total,0,',','.') ?></span></h4><a class="btn btn-success btn-lg" href="checkout.php">Buat Pesanan</a></div><?php endif; ?>
<?php include "includes/footer.php"; ?>
