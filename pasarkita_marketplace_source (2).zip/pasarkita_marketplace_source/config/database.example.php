<?php
// Salin file ini ke database.php dan sesuaikan kredensial hosting.
// Jangan unggah kredensial asli ke repository publik.
$host = "localhost";
$user = "root";
$pass = "";
$db   = "marketplace_tradisional";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi database gagal. Periksa konfigurasi database.");
}
$conn->set_charset("utf8mb4");
